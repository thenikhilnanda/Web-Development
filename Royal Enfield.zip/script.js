
// document.body.style.backgroundColor= "red";
// for making all backgroun red in color

function fn() {
    var a = document.getElementById("uname").value;
    var b = document.getElementById("pass").value;
    // we've created seperate id's for username & password inside input tag in .html file
    // .value used to store user inputs
    // var a, var b used to store all funtions

    // FOR CREATING AN simple ALERT
    // alert("The entered username is"+a +"The entered password is" +b);


    //TO CHECK WHETHER THE ENTERED VALUE IS MATCHING OR NOT using IF/ELSE
    // if (a == "xxxtenta" && b == "makeOuthill") {
    //     alert("Username and Password is matching");
    // }
    // else {
    //     alert("Username and Password is Not Matching")
    // }

    // IF USER IS NOT ENTERING ANYTING INSIDE AN PLACEHOLDER
    if (a == "" && b == "") {
        // alert("Username and Password is required");
        document.getElementById("h6uname").innerHTML = "Username is required ";
        document.getElementById("h6pass").innerHTML = "Password is required";
        return false;
    }

    else if (a == "") {
        // alert("Username is required");

        document.getElementById("h6uname").innerHTML = "Username is required";
        // We used this to create an alert right below the placeholder
        return false;

    }

    else if (b == "") {
        // alert("Password is required");
        document.getElementById("h6pass").innerHTML = "Password is required";
        return false;
    }

    else if (a == "xxxtenta" && b == "makeOuthill") {
        alert("Username and Password is matching");
        return true;
    }

    else {
        // alert("Username and Password is Not Matching");
        document.getElementById("h6btn").innerHTML = "Username and Password is not matching";
        return false;
    }

}