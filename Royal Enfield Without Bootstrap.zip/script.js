function scroll() {
    a = document.getElementById("img")
    if (a.src.match("ladakh poster.webp")) {
        document.getElementById("img").src = "racing poster.jpg"
    }

    else if (a.src.match("racing poster.jpg")) {
        document.getElementById("img").src = "himlayaan poster.jpg"
    }

    else (a.src.match("himlayaan poster.jpg")) {
        document.getElementById("img").src = "himlayaan poster.jpg"
    }

}


// Slide section js starts here

function Hunter() {
    document.getElementById("Bikes").src = "./image path";
}

function Scram() {
    document.getElementById("Bikes").src = "./image path";
}

function Classic() {
    document.getElementById("Bikes").src = "./image path";
}

function Inerceptor() {
    document.getElementById("Bikes").src = "./image path";
}

function Contenental() {
    document.getElementById("Bikes").src = "./image path";
}

function Meteor() {
    document.getElementById("Bikes").src = "./image path";
}

function Himalayaan() {
    document.getElementById("Bikes").src = "./image path";
}

function Bullet() {
    document.getElementById("Bikes").src = "./image path";
}



